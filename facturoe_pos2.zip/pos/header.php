<header  >

<img src="../pos/img/logo_010419.png" width="110" height="20">
&nbsp&nbsp

<a  href="../pos/">
    <button>POS</button>
  </a> 
  <a  href="../inventario_f/">
    <button>Inventario</button>
  </a> 
  <a  href="../clientes/">
    <button>Clientes</button>
  </a> 

  
  <a   href="../informes/">
    <button>Informes</button>
  </a> 

  <a   href="../configuracion/">
    <button>Configuración</button>
  </a> 
  <a   href="../login/salir.php">
    <button>Salir</button>
  </a> 

</header>